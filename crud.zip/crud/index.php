<!DOCTYPE html>
<html>
    <head>
        <title>PHP exo</title>
    </head>

    <body>
    
	<?php
		include 'mesFunctionsSQL.php';
		include 'mesFunctionsTable.php';

		$headers = getHeaderTable();
		$users = getAllUsers();
		afficherTableau($users, $headers);
	?>

	<a href=formulaireUtilisateur.php?id=0 >Creer un article</a> 
	<a href="accueil.php">Retour</a>
    </body>
</html>

