<?php
	include 'mesFunctionsSQL.php';
	include 'mesFunctionsTable.php';
	$action = $_GET["action"];

	if ($action == "DELETE") {
		$id = $_GET["id"];
	} else {
		$id = $_GET["id"];
		$nomArticles = $_GET["nomArticles"];
		$descriptionArticles = $_GET["descriptionArticles"];
		$prixArticles = $_GET["prixArticles"];
		
	}
	

	if ($action == "CREATE") {
		createUser($nomArticles, $descriptionArticles, $prixArticles);

		echo "article cree <br>";
		echo "<a href='index.php'>Liste des articles</a>";
		
	}
	
	if ($action == "UPDATE") {
		updateUser($id, $nomArticles, $descriptionArticles, $prixArticles);
		echo "article update <br>";
		echo "<a href='index.php'>Liste des articles</a>";
	}
	if ($action == "DELETE") {
		deleteUser($id);
		echo "article delete <br>";
		echo "<a href='index.php'>Liste des articles</a>";
	}
	

	
?>